package MyWork;
import java.io.File;

public class GetFromHTML2014302580164 {

	public static void GetFromHTML()
	{
		String my_URL = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Sheng%20Li";
		HttpRequest my_request = HttpRequest.get(my_URL);
		String my_File = "web1.html";
		my_request.receive(new File (my_File));
	}

}
