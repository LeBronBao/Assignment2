import java.io.File;
import java.io.FileWriter;
import java.io.IOException;  
import java.util.regex.*; 

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580141 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//Invoke a static method to copy the information and store it in file with format of HTML
		//Capture2014302580141.catchWebpage();
		
		//Read the HTML file and turn it into document.
		File originalFile = new File("Teacher2.html");
		Document doc = Jsoup.parse(originalFile,"GB2312");  //Take the format of web page seriously.
		
		//Get the element that contains the phone number and e-mail.
		Element element = doc.getElementById("n3");
		Element introduction = doc.getElementById("n2");
		Element researchDirection = doc.getElementById("n1");
		
		//Get the texts that are included by the tag "<p>".
		Elements e_mail = element.select("p");
		Elements intro = introduction.select("p");
		Elements research = researchDirection.select("p");
		
		//Get the real content in the label <p>.
		String str = e_mail.text();
		String introText = intro.text();
		String researchText = research.text();
		
		
		//Divide a string into several parts and each part has different meaning from others.
		String email1 = str.substring(36, 60);//Get the e-main.
		String phoneNumber = str.substring(66, 78);//Get the phone number.
		
		//Invoke methods to return the information.
		String content = doc.toString();
		String email2 = getEmailByRegularExpression(content);
		String phoneNumber2 = getPhoneNumberByRegularExpression(content);
		
		//Write the information into the TXT file.
		File outputFile = new File("Introduction.txt");
		try{
			FileWriter out = new FileWriter(outputFile);
			out.write("�������ξ��");
			out.write("\r\n");
			out.write("���˼�飺"+introText);
			out.write("\r\n");
			out.write("�о�����"+researchText);
			out.write("\r\n");
			out.write("�����ʼ���"+email2);
			out.write("\r\n");
			out.write("��ϵ�绰��"+phoneNumber2);
			out.close();
		}catch(Exception e1){
			e1.printStackTrace();
		}
		
	
		
	}
	
	//Method to get e-mail by regular expression.
 	public static String getEmailByRegularExpression(String str){
		String temp = null;
		String regex = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";  
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);
		while(m.find()){
			temp = m.group();
		}
		return temp;
	}
	
 	//Method to get phone numbers by regular expression.
	public static String getPhoneNumberByRegularExpression(String str){
		String temp = null;
		String regex = "0\\w{2}-\\w{8}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(str);
		while(m.find()){
			temp = m.group();
		}
		return temp;
	}
	


}
