import java.io.File;

public class Capture2014302580141 {
	public static void catchWebpage(){
		
		String targetUrl = "http://userweb.swjtu.edu.cn/Userweb/renjuanjuan/index.htm";
		
		HttpRequest request = HttpRequest.get(targetUrl);
		
		String myFile = "Teacher2.html";
		
		request.receive(new File(myFile));
	}
}
